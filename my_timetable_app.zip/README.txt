MY TIMETABLE — QUICK SETUP

WHAT'S INCLUDED
- index.html: the app
- manifest.json: installable-app settings
- service-worker.js: basic offline caching

IMPORTANT
The easiest reliable way to keep this as an app icon on your iPhone is to host these files on a secure HTTPS static website, then use Safari > Share > Add to Home Screen. Opening the HTML file directly is fine for testing, but it may not install as a proper home-screen web app.

SIMPLE HOSTING OPTION: GITHUB PAGES
1. On a computer, sign in to GitHub and create a new repository (for example, my-timetable). A public repository is simplest for free GitHub Pages.
2. Upload index.html, manifest.json, and service-worker.js to the repository's main/root folder.
3. Open repository Settings > Pages. Under Build and deployment, choose deploy from a branch, select main and /(root), then Save.
4. Wait for GitHub Pages to publish the site. Open the published HTTPS URL in Safari on your iPhone.
5. Tap Share (square with arrow) > Add to Home Screen > Add.
6. Open it from the new home-screen icon.

USING THE APP
- Tap Edit timetable to add each weekday's subjects and start/end times.
- Choose the weekday in the editor to set up another day.
- Tap ⚙ to choose one of four themes.
- Timetable data is saved in the browser on that device. Avoid clearing Safari website data, and keep a separate note of your timetable as a backup.
- This starter version stores data locally on each device; it does not sync changes between your iPhone and tablet automatically.
